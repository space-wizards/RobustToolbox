* `background.png` a modified version from http://imgarcade.com/16-bit-space-background.html
* `logo.png` is a modified version of the logo on http://spacestation13.com
* `nt.png` is an exported PNG from https://github.com/Baystation12/Baystation12/blob/0eb51892d0cd84a04aeebd6b8c8dcfbd92d2b35a/tgui/src/images/nanotrasen.svg
